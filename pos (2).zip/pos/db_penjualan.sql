-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 01 Jul 2025 pada 09.00
-- Versi Server: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: db_penjualan
--

-- --------------------------------------------------------

--
-- Struktur dari tabel tbl_barang
--

CREATE TABLE IF NOT EXISTS tbl_barang (
  barang_id varchar(15) NOT NULL,
  barang_nama varchar(150) DEFAULT NULL,
  barang_satuan varchar(30) DEFAULT NULL,
  barang_harpok double DEFAULT NULL,
  barang_harjul double DEFAULT NULL,
  barang_harjul_grosir double DEFAULT NULL,
  barang_stok int(11) DEFAULT '0',
  barang_min_stok int(11) DEFAULT '0',
  barang_tgl_input timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  barang_tgl_last_update datetime DEFAULT NULL,
  barang_kategori_id int(11) DEFAULT NULL,
  barang_user_id int(11) DEFAULT NULL,
  PRIMARY KEY (barang_id),
  KEY barang_user_id (barang_user_id),
  KEY barang_kategori_id (barang_kategori_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel tbl_barang
--

INSERT INTO tbl_barang (barang_id, barang_nama, barang_satuan, barang_harpok, barang_harjul, barang_harjul_grosir, barang_stok, barang_min_stok, barang_tgl_input, barang_tgl_last_update, barang_kategori_id, barang_user_id) VALUES
('BR000001', 'Apel Fuji', 'Kg', 25000, 35000, 30000, 50, 10, '2025-07-01 00:00:00', NULL, 5, 1),
('BR000002', 'Jeruk Medan', 'Kg', 15000, 22000, 18000, 40, 10, '2025-07-01 00:00:00', NULL, 5, 1),
('BR000003', 'Anggur Import', 'Kg', 40000, 60000, 50000, 30, 5, '2025-07-01 00:00:00', NULL, 5, 1),
('BR000004', 'Semangka', 'Buah', 20000, 30000, 25000, 20, 5, '2025-07-01 00:00:00', NULL, 5, 1),
('BR000005', 'Bayam', 'Ikat', 5000, 8000, 6000, 100, 20, '2025-07-01 00:00:00', NULL, 6, 1),
('BR000006', 'Wortel', 'Kg', 10000, 15000, 12000, 60, 15, '2025-07-01 00:00:00', NULL, 6, 1),
('BR000007', 'Brokoli', 'Buah', 12000, 18000, 15000, 40, 10, '2025-07-01 00:00:00', NULL, 6, 1),
('BR000008', 'Cabe Merah', 'Kg', 30000, 45000, 35000, 25, 5, '2025-07-01 00:00:00', NULL, 6, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel tbl_beli
--

CREATE TABLE IF NOT EXISTS tbl_beli (
  beli_nofak varchar(15) DEFAULT NULL,
  beli_tanggal date DEFAULT NULL,
  beli_suplier_id int(11) DEFAULT NULL,
  beli_user_id int(11) DEFAULT NULL,
  beli_kode varchar(15) NOT NULL,
  PRIMARY KEY (beli_kode),
  KEY beli_user_id (beli_user_id),
  KEY beli_suplier_id (beli_suplier_id),
  KEY beli_id (beli_kode)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel tbl_detail_beli
--

CREATE TABLE IF NOT EXISTS tbl_detail_beli (
  d_beli_id int(11) NOT NULL AUTO_INCREMENT,
  d_beli_nofak varchar(15) DEFAULT NULL,
  d_beli_barang_id varchar(15) DEFAULT NULL,
  d_beli_harga double DEFAULT NULL,
  d_beli_jumlah int(11) DEFAULT NULL,
  d_beli_total double DEFAULT NULL,
  d_beli_kode varchar(15) DEFAULT NULL,
  PRIMARY KEY (d_beli_id),
  KEY d_beli_barang_id (d_beli_barang_id),
  KEY d_beli_nofak (d_beli_nofak),
  KEY d_beli_kode (d_beli_kode)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel tbl_detail_jual
--

CREATE TABLE IF NOT EXISTS tbl_detail_jual (
  d_jual_id int(11) NOT NULL AUTO_INCREMENT,
  d_jual_nofak varchar(15) DEFAULT NULL,
  d_jual_barang_id varchar(15) DEFAULT NULL,
  d_jual_barang_nama varchar(150) DEFAULT NULL,
  d_jual_barang_satuan varchar(30) DEFAULT NULL,
  d_jual_barang_harpok double DEFAULT NULL,
  d_jual_barang_harjul double DEFAULT NULL,
  d_jual_qty int(11) DEFAULT NULL,
  d_jual_diskon double DEFAULT NULL,
  d_jual_total double DEFAULT NULL,
  PRIMARY KEY (d_jual_id),
  KEY d_jual_barang_id (d_jual_barang_id),
  KEY d_jual_nofak (d_jual_nofak)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel tbl_detail_jual
--

INSERT INTO tbl_detail_jual (d_jual_id, d_jual_nofak, d_jual_barang_id, d_jual_barang_nama, d_jual_barang_satuan, d_jual_barang_harpok, d_jual_barang_harjul, d_jual_qty, d_jual_diskon, d_jual_total) VALUES
(1, '010725000001', 'BR000001', 'Apel Fuji', 'Kg', 25000, 35000, 2, 0, 70000),
(2, '010725000001', 'BR000005', 'Bayam', 'Ikat', 5000, 8000, 3, 1000, 23000),
(3, '010725000001', 'BR000006', 'Wortel', 'Kg', 10000, 15000, 1, 0, 15000),
(4, '010725000002', 'BR000003', 'Anggur Import', 'Kg', 40000, 60000, 1, 0, 60000),
(5, '010725000002', 'BR000007', 'Brokoli', 'Buah', 12000, 18000, 1, 0, 18000),
(6, '020725000001', 'BR000002', 'Jeruk Medan', 'Kg', 15000, 22000, 5, 10000, 100000),
(7, '020725000001', 'BR000008', 'Cabe Merah', 'Kg', 30000, 45000, 2, 5000, 85000),
(8, '020725000001', 'BR000004', 'Semangka', 'Buah', 20000, 30000, 1, 0, 30000);

-- --------------------------------------------------------

--
-- Struktur dari tabel tbl_jual
--

CREATE TABLE IF NOT EXISTS tbl_jual (
  jual_nofak varchar(15) NOT NULL,
  jual_tanggal timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  jual_total double DEFAULT NULL,
  jual_jml_uang double DEFAULT NULL,
  jual_kembalian double DEFAULT NULL,
  jual_user_id int(11) DEFAULT NULL,
  jual_keterangan varchar(20) DEFAULT NULL,
  PRIMARY KEY (jual_nofak),
  KEY jual_user_id (jual_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel tbl_jual
--

INSERT INTO tbl_jual (jual_nofak, jual_tanggal, jual_total, jual_jml_uang, jual_kembalian, jual_user_id, jual_keterangan) VALUES
('010725000001', '2025-07-01 09:15:22', 105000, 120000, 15000, 1, 'eceran'),
('010725000002', '2025-07-01 10:30:45', 78000, 100000, 22000, 2, 'eceran'),
('020725000001', '2025-07-02 11:45:18', 215000, 250000, 35000, 1, 'grosir');

-- --------------------------------------------------------

--
-- Struktur dari tabel tbl_kategori
--

CREATE TABLE IF NOT EXISTS tbl_kategori (
  kategori_id int(11) NOT NULL AUTO_INCREMENT,
  kategori_nama varchar(35) DEFAULT NULL,
  PRIMARY KEY (kategori_id)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel tbl_kategori
--

INSERT INTO tbl_kategori (kategori_id, kategori_nama) VALUES
(5, 'Buah'),
(6, 'Sayur');

-- --------------------------------------------------------

--
-- Struktur dari tabel tbl_retur
--

CREATE TABLE IF NOT EXISTS tbl_retur (
  retur_id int(11) NOT NULL AUTO_INCREMENT,
  retur_tanggal timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  retur_barang_id varchar(15) DEFAULT NULL,
  retur_barang_nama varchar(150) DEFAULT NULL,
  retur_barang_satuan varchar(30) DEFAULT NULL,
  retur_harjul double DEFAULT NULL,
  retur_qty int(11) DEFAULT NULL,
  retur_subtotal double DEFAULT NULL,
  retur_keterangan varchar(150) DEFAULT NULL,
  PRIMARY KEY (retur_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel tbl_suplier
--

CREATE TABLE IF NOT EXISTS tbl_suplier (
  suplier_id int(11) NOT NULL AUTO_INCREMENT,
  suplier_nama varchar(35) DEFAULT NULL,
  suplier_alamat varchar(60) DEFAULT NULL,
  suplier_notelp varchar(20) DEFAULT NULL,
  PRIMARY KEY (suplier_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel tbl_user
--

CREATE TABLE IF NOT EXISTS tbl_user (
  user_id int(11) NOT NULL AUTO_INCREMENT,
  user_nama varchar(35) DEFAULT NULL,
  user_username varchar(30) DEFAULT NULL,
  user_password varchar(35) DEFAULT NULL,
  user_level varchar(2) DEFAULT NULL,
  user_status varchar(2) DEFAULT '1',
  PRIMARY KEY (user_id)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel tbl_user
--

INSERT INTO tbl_user (user_id, user_nama, user_username, user_password, user_level, user_status) VALUES
(1, 'nuelta ginting', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1', '1'),
(2, 'nazira', 'kasir', 'e10adc3949ba59abbe56e057f20f883e', '2', '1');

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel tbl_barang
--
ALTER TABLE tbl_barang
  ADD CONSTRAINT tbl_barang_ibfk_1 FOREIGN KEY (barang_user_id) REFERENCES tbl_user (user_id) ON UPDATE CASCADE,
  ADD CONSTRAINT tbl_barang_ibfk_2 FOREIGN KEY (barang_kategori_id) REFERENCES tbl_kategori (kategori_id) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel tbl_beli
--
ALTER TABLE tbl_beli
  ADD CONSTRAINT tbl_beli_ibfk_1 FOREIGN KEY (beli_user_id) REFERENCES tbl_user (user_id) ON UPDATE CASCADE,
  ADD CONSTRAINT tbl_beli_ibfk_2 FOREIGN KEY (beli_suplier_id) REFERENCES tbl_suplier (suplier_id) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel tbl_detail_beli
--
ALTER TABLE tbl_detail_beli
  ADD CONSTRAINT tbl_detail_beli_ibfk_1 FOREIGN KEY (d_beli_barang_id) REFERENCES tbl_barang (barang_id) ON UPDATE CASCADE,
  ADD CONSTRAINT tbl_detail_beli_ibfk_2 FOREIGN KEY (d_beli_kode) REFERENCES tbl_beli (beli_kode) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel tbl_detail_jual
--
ALTER TABLE tbl_detail_jual
  ADD CONSTRAINT tbl_detail_jual_ibfk_1 FOREIGN KEY (d_jual_barang_id) REFERENCES tbl_barang (barang_id) ON UPDATE CASCADE,
  ADD CONSTRAINT tbl_detail_jual_ibfk_2 FOREIGN KEY (d_jual_nofak) REFERENCES tbl_jual (jual_nofak) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel tbl_jual
--
ALTER TABLE tbl_jual
  ADD CONSTRAINT tbl_jual_ibfk_1 FOREIGN KEY (jual_user_id) REFERENCES tbl_user (user_id) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
